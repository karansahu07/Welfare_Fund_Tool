import { NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import Payment from '@/models/paymentModel';

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const utr = formData.get('utr') as string;
    const name = formData.get('name') as string;
    const amount = formData.get('amount') as string;
    const file = formData.get('screenshot') as File;

    if (!utr || !name || !amount || !file) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const base64Image = `data:${file.type};base64,${buffer.toString('base64')}`;

    await connectDB();

    const newPayment = new Payment({
      utr,
      name,
      amount: Number(amount),
      screenshotUrl: base64Image,
      // status: 'pending',
    });

    await newPayment.save();

    return NextResponse.json({ message: 'Payment saved successfully' }, { status: 201 });

  } catch (error) {
    console.error('❌ Payment Save Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
